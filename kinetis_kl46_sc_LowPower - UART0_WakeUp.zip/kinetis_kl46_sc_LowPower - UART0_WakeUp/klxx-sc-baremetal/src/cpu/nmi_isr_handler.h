/* File:         nmi_isr_handler.h
 * Purpose:     Provides routines for handling nmi isr.
 *
 * Notes:	
 *              
 */
void nmi_isr(void);
void enable_NMI_button(void);

