#ifndef _LOWPOWER_MODE_H_
#define _LOWPOWER_MODE_H_

typedef enum {
  NormalRun_AllClockOn          = 0,    /* RUN mode with all peripheral clocks enabled */
  NormalRun_AllColckOff         = 1,    /* RUN mode with all peripheral clocks disabled */
  NormalWait_AllClockOn         = 2,    /* WAIT mode with all peripheral clocks enabled */
  NormalWait_AllClockOff        = 3,    /* WAIT mode with all peripheral clocks disabled */
  NormalStop                    = 4,    /* Stop mode */
  PSTOP1                        = 5,    /* Partial stop mode 1 */
  PSTOP2                        = 6,    /* Partial stop mode 2 */
  VLPR_AllClockOn               = 7,    /* very low power run mode with all peripheral clocks enabled */
  VLPR_AllClockOff              = 8,    /* very low power run mode with all peripheral clocks disabled */
  VLPW_AllClockOn               = 9,    /* very low power wait mode with all peripheral clocks enabled */
  VLPW_AllClockOff              = 10,   /* very low power run mode with all peripheral clocks disabled */
  VLPS                          = 11,   /* very low power stop mode */
  LLS                           = 12,   /* low-leakage stop mode */
  VLLS3                         = 13,   /* low-leakage stop3 mode */
  VLLS1                         = 14,   /* low-leakage stop1 mode */
  VLLS0                         = 15    /* low-leakage stop1 mode  */
} LowPowerMode_Index;


#endif //End of "lowpower_modes.h"