
 /**
  \mainpage 
  \n Copyright (c) 2011 Freescale
  \brief 
  \author   	Freescale 
  \author    
  \version      m.n
  \date         Feb 15, 2012
  
  Put here all the information needed of the Project. Basic configuration as well as information on
  the project definition will be very useful 
*/
/****************************************************************************************************/
/*                                                                                                  */
/* All software, source code, included documentation, and any implied know-how are property of      */
/* Freescale Semiconductor and therefore considered CONFIDENTIAL INFORMATION.                       */
/* This confidential information is disclosed FOR DEMONSTRATION PURPOSES ONLY.                      */
/*                                                                                                  */
/* All Confidential Information remains the property of Freescale Semiconductor and will not be     */
/* copied or reproduced without the express written permission of the Discloser, except for copies  */
/* that are absolutely necessary in order to fulfill the Purpose.                                   */
/*                                                                                                  */
/* Services performed by FREESCALE in this matter are performed AS IS and without any warranty.     */
/* CUSTOMER retains the final decision relative to the total design and functionality of the end    */
/* product.                                                                                         */
/* FREESCALE neither guarantees nor will be held liable by CUSTOMER for the success of this project.*/
/*                                                                                                  */
/* FREESCALE disclaims all warranties, express, implied or statutory including, but not limited to, */
/* implied warranty of merchantability or fitness for a particular purpose on any hardware,         */
/* software ore advise supplied to the project by FREESCALE, and or any product resulting from      */
/* FREESCALE services.                                                                              */
/* In no event shall FREESCALE be liable for incidental or consequential damages arising out of     */
/* this agreement. CUSTOMER agrees to hold FREESCALE harmless against any and all claims demands or */
/* actions by anyone on account of any damage,or injury, whether commercial, contractual, or        */
/* tortuous, rising directly or indirectly as a result of the advise or assistance supplied CUSTOMER*/ 
/* in connectionwith product, services or goods supplied under this Agreement.                      */
/*                                                                                                  */
/****************************************************************************************************/

/*****************************************************************************************************
* Include files
*****************************************************************************************************/
#include "common.h"
#include "low_power_demo.h"
#include "llwu.h"
#include "smc.h"
#include "mcg.h"
#include "pmc.h"
#include "uart.h"
#include "vectors.h"
#include "lptmr.h"
#include "coremark.h"
#include "nmi_isr_handler.h"
#include "rtc.h"

/*****************************************************************************************************
* Declaration of module wide TYPEs - NOT for use in other modules
*****************************************************************************************************/

/*****************************************************************************************************
* Definition of module wide VARIABLEs - NOT for use in other modules
*****************************************************************************************************/
unsigned char measureFlag = 0;
unsigned char enterVLLSOflag = 0;
unsigned char Data_Buffer[BUFFER_SIZE];
unsigned int r_cnt=0;

extern int mcg_clk_hz;
extern int mcg_clk_khz;
extern int core_clk_khz;
extern int uart0_clk_khz;

extern void enable_NMI_button(void);
void LowPowerModes_UART0WakeUp(void);

int fast_irc_freq = 4000000; //4000000; // default fast irc frequency is 4MHz
int slow_irc_freq = 32768; // default slow irc frequency is 32768Hz

/*****************************************************************************************************
* Definition of module wide (CONST-) CONSTANTs - NOT for use in other modules
*****************************************************************************************************/
#define MCG_OUT_FREQ    48000000
#define CPO_LOOP_CNT    2
#define IO_NMI_DEF      1  // 1 - sets the Port interrupt, 0 - sets the NMI interrupt         
#define TESTPIN_ENABLE          PORTE_PCR1 |= PORT_PCR_MUX(1);\
                                GPIOE_PDDR |= 1<<1 
#define TESTPIN_HIGH            GPIOE_PSOR |= 1<<1
#define TESTPIN_LOW             GPIOE_PCOR |= 1<<1
#define TESTPIN_TOGGLE          GPIOE_PTOR |= 1<<1                     
/****************************************************************************************************/
//#define NOT_LOWEST_PWR 1    // define this to leave debugger enabled
//#define NOT_LOWEST_PWR_2 1  // define this to leave uart clock gate on
/*****************************************************************************************************
* Code of project wide FUNCTIONS
*****************************************************************************************************/

char uartx_getchar(void)
{
#if TERM_PORT_NUM == 2
  return uart_getchar(UART2_BASE_PTR);
    
#elif TERM_PORT_NUM == 0
   return uart0_getchar(UART0_BASE_PTR);
   
#elif TERM_PORT_NUM == 1
   return uart_getchar(UART1_BASE_PTR);
#endif
   
}

void uartx_putchar(char ch)
{
#if TERM_PORT_NUM == 2
   uart_putchar(UART2_BASE_PTR,ch);
    
#elif TERM_PORT_NUM == 0
    uart0_putchar(UART0_BASE_PTR,ch);
   
#elif TERM_PORT_NUM == 1
    uart_putchar(UART1_BASE_PTR,ch);
#endif
}


void LEDS_ON(void)
{
  LED0_ON;
  LED1_ON;
}


void LEDS_OFF(void)
{
  LED0_OFF;
  LED1_OFF;
}

int main (void)
{
        /* Enable all operation modes because this is a write once register*/  
        SMC_PMPROT =  SMC_PMPROT_AVLLS_MASK |
                      SMC_PMPROT_ALLS_MASK  |    
                      SMC_PMPROT_AVLP_MASK;

        /* PTC3(SW1) is configured to wake up MCU from VLLSx and LLS modes */
        LLWU_Init(); 
        
        SW_LED_Init();
        
        EnableInterrupts;
        
        /*Start test*/
        LowPowerModes_UART0WakeUp();
}
/*********************************************************************
** Case 1: Wakeup by data received interrupt, UART0 standby under VLPS.
           The current is about 60uA, as UART0 clock is active under vlps.

** Case 2: Wakeup by RxD active edge interrupt, UART0 inactive under VLPS.
           The current is about 2.9uA.
*********************************************************************/
void LowPowerModes_UART0WakeUp(void)
{
  unsigned char op_mode,test_val;  
  int test_num = UNDEF_VALUE;
  int i;
  
  
  printf("\n\r*------------------------------------------------------------*");
  printf("\n\r*             KL Low Power UART0 wakeup DEMO                 *");
  printf("\n\r*                    %s %s                    *", __DATE__, __TIME__);
  printf("\n\r*------------------------------------------------------------*\n\r");
  
  while(1)
  {
     while (test_num > 22 | test_num < 0)
      {
         LEDS_ON();
                   
         if ((SMC_PMSTAT & SMC_PMSTAT_PMSTAT_MASK)== 4)
         {
              printf("in VLPR Mode !  \r\n");
         } else if ((SMC_PMSTAT & SMC_PMSTAT_PMSTAT_MASK)== 1)
         {
              printf("in Run Mode  !  \r\n");                               
         }
         op_mode = what_mcg_mode();
         if (op_mode ==1) 
             printf("in BLPI mode now at %d Hz\r\n",mcg_clk_hz );
         if (op_mode ==2) 
             printf("in FBI mode now at %d Hz\r\n",mcg_clk_hz );
         if (op_mode ==3) 
             printf("in FEI mode now at %d Hz\r\n",mcg_clk_hz );
         if (op_mode ==4) 
             printf("in FEE mode now at %d Hz\r\n",mcg_clk_hz );
         if (op_mode ==5) 
             printf("in FBE mode now at %d Hz\r\n",mcg_clk_hz );
         if (op_mode ==6) 
             printf("in BLPE mode now at %d Hz\r\n",mcg_clk_hz );
         if (op_mode ==7) 
             printf("in PBE mode now at %d Hz\r\n",mcg_clk_hz );
         if (op_mode ==8) 
             printf("in PEE mode now at %d Hz\r\n",mcg_clk_hz );
         
          printf("\n\rSelect the desired operation \n\r");
          printf("1 for CASE 1: Enter VLPS with UART0 data received wakeup\n\r");
          printf("2 for CASE 2: Enter VLPS with UART0 edge wakeup\n\r");          
          printf("\n> ");
          
          test_val = uartx_getchar();
          
          uartx_putchar(test_val);
          printf("\n\r");

          if((test_val>=0x30) && (test_val<=0x39))
            test_num = test_val - 0x30;
          else if((test_val>='A') && (test_val<='C'))
            test_num = test_val - 0x37;
          else if((test_val>='a') && (test_val<='c'))
            test_num = test_val - 0x57; 
       }
  
        LEDS_OFF();

        switch(test_num)
        {                        
          case 1:// Wakeup by data received interrupt under VLPS.
            printf("Press any key to enter VLPS operation1\n\r");
            uartx_getchar();
            
            clockMonitor(OFF);
            TESTPIN_ENABLE;
            TESTPIN_LOW;
            uart_lowpower_data();
            printf("Send data to wakeup UART0 from VLPS\n\r");
            /*Go to VLPS*/
            enter_vlps();  //1 Means: Any interrupt could wake up from this mode
            TESTPIN_HIGH;
            if ((SMC_PMSTAT & SMC_PMSTAT_PMSTAT_MASK)== 4)
            {
                printf("Back to VLPR Mode from VLPS!\n\r");
            } 
            else if ((SMC_PMSTAT & SMC_PMSTAT_PMSTAT_MASK)== 1)
            {              
#ifdef FEE_32OSC
                if(FEE==op_mode)
#else
                if(FEI==op_mode)
#endif
                  printf("Back to RUN mode from VLPS \n\r");               
                else{
                  printf("Error: Failed to Back to RUN mode \n\r");
                  clockMonitor(ON);
                }
            }
            /* wait the whole package data are received */
            while(!(UART0_S1&UART0_S1_IDLE_MASK));      // once the data package was received entirely, the IDLE flag is set.
              UART0_S1 |= UART0_S1_IDLE_MASK;           // Clear IDLE flag
            UART0_C2 &= ~UART0_C2_RIE_MASK;             // disable receive interrupt
            printf("The whole data package was received\n\r");
            for(i=0;i<r_cnt;i++)
              printf("%d ",*(Data_Buffer+i));           // print the received data       
            printf("\n\r");
            r_cnt = 0;
            
            break;
        
           case 2://// Wakeup by RXD edge interrupt under VLPS.
            printf("Press any key to enter VLPS operation2\n\r");
            uartx_getchar();
            
            clockMonitor(OFF);
            TESTPIN_ENABLE;
            TESTPIN_LOW;
            uart_lowpower_edge();
            printf("Send  data to UART0 edge wake up from VLPS\n\r");
            /*Go to VLPS*/
            enter_vlps();  //1 Means: Any interrupt could wake up from this mode
            UART0_BDH &= ~UART0_BDH_RXEDGIE_MASK;
            TESTPIN_HIGH;
            if ((SMC_PMSTAT & SMC_PMSTAT_PMSTAT_MASK)== 4)
            {
                printf("Back to VLPR Mode from VLPS!\n\r");
            } 
            else if ((SMC_PMSTAT & SMC_PMSTAT_PMSTAT_MASK)== 1)
            {              
#ifdef FEE_32OSC
                if(FEE==op_mode)
#else
                if(FEI==op_mode)
#endif
                  printf("Back to RUN mode from VLPS \n\r");               
                else{
                  printf("Error: Failed to Back to RUN mode \n\r");
                  clockMonitor(ON);
                }
            }
           /* wait the whole package data are received */
            while(!(UART0_S1&UART0_S1_IDLE_MASK));      // once the data package was received entirely, the IDLE flag is set.
            UART0_S1 |= UART0_S1_IDLE_MASK;             // Clear IDLE flag        
            UART0_C2 &= ~UART0_C2_RIE_MASK;             // disable receive interrupt
            for(i=0;i<r_cnt;i++)
              printf("%d ",*(Data_Buffer+i));           // print the received data         
            printf("\n\r");
            r_cnt = 0;
            break;           

        default:
            break;
        }
        
        test_num = UNDEF_VALUE ;  
  }
  
}


void LPTMR_init(int count, int clock_source)
{
    SIM_SCGC5 |= SIM_SCGC5_LPTMR_MASK;
    enable_irq(LPTMR_irq_no);

    LPTMR0_PSR = ( LPTMR_PSR_PRESCALE(0) // 0000 is div 2
                 | LPTMR_PSR_PBYP_MASK  // LPO feeds directly to LPT
                 | LPTMR_PSR_PCS(clock_source)) ; // use the choice of clock
    if (clock_source== 0)
      printf("\n\r LPTMR Clock source is the MCGIRCLK \n\r");
    if (clock_source== 1)
      printf("\n\r LPTMR Clock source is the LPOCLK \n\r");
    if (clock_source== 2)
      printf("\n\r LPTMR Clock source is the ERCLK32 \n\r");
    if (clock_source== 3)
      printf("\n\r LPTMR Clock source is the OSCERCLK \n\r");
             
    LPTMR0_CMR = LPTMR_CMR_COMPARE(count);  //Set compare value

    LPTMR0_CSR =(  LPTMR_CSR_TCF_MASK   // Clear any pending interrupt
                 | LPTMR_CSR_TIE_MASK   // LPT interrupt enabled
                 | LPTMR_CSR_TPS(0)     //TMR pin select
                 |!LPTMR_CSR_TPP_MASK   //TMR Pin polarity
                 |!LPTMR_CSR_TFC_MASK   // Timer Free running counter is reset whenever TMR counter equals compare
                 |!LPTMR_CSR_TMS_MASK   //LPTMR0 as Timer
                );
    LPTMR0_CSR |= LPTMR_CSR_TEN_MASK;   //Turn on LPT and start counting
}
/*******************************************************************************************************/
void LLWU_Init(void)
{
    enable_irq(LLWU_irq_no);
    //enable_irq(LPTMR_irq_no);

   // llwu_configure(0x0080/*PTC3*/, LLWU_PIN_FALLING, 0x1);
    llwu_configure(0x0080/*PTC3*/, LLWU_PIN_FALLING, 0x1);
}

/*******************************************************************************************************/
void SW_LED_Init(void)
{

   SIM_SCGC5 |= SIM_SCGC5_PORTA_MASK | SIM_SCGC5_PORTB_MASK |SIM_SCGC5_PORTC_MASK ; /* PORT clock enablement */    
       
   LED0_EN; 
   LED1_EN; 
}


void demo_lptmr_isr(void)
{
  volatile unsigned int dummyread;
  if(MCM_CPO & MCM_CPO_CPOACK_MASK)
  {
      MCM_CPO &= ~MCM_CPO_CPOREQ_MASK;
      while (MCM_CPO & MCM_CPO_CPOACK_MASK);                
      printf("         \n\rLPTRM Interrupt pulled OUT of Compute Mode  \n\r");               
  }
  SIM_SCGC5 |= SIM_SCGC5_LPTMR_MASK;
  printf(" \r[demo_lptmr_isr] \n\r  > ");
 
  LPTMR0_CSR |=  LPTMR_CSR_TCF_MASK;   // write 1 to TCF to clear the LPT timer compare flag
  LPTMR0_CSR = ( LPTMR_CSR_TEN_MASK | LPTMR_CSR_TIE_MASK | LPTMR_CSR_TCF_MASK  );
      // enable timer
      // enable interrupts
      // clear the flag
  /*wait for write to complete to  before returning */  
  dummyread = LPTMR0_CSR;

  return;

}


/*******************************************************************************************************/
void uart_configure(int clock_khz,int uart0_clk_src )
{
     int mcg_clock_khz;
     int core_clock_khz;
     int periph_clk_khz;
  
     
     SIM_SOPT2 &= ~SIM_SOPT2_UART0SRC_MASK; // first clear the uart0 clk source field
     SIM_SOPT2 &= ~SIM_SOPT2_UART0SRC_MASK; // first clear the uart0 clk source field
     SIM_SOPT2 |= uart0_clk_src ; // select the UART0 clock source
     
     if (TERM_PORT_NUM == 0){
        uart0_init (UART0_BASE_PTR, clock_khz, TERMINAL_BAUD); 
     }else {
        mcg_clock_khz = clock_khz ; /// 1000
        core_clock_khz = mcg_clock_khz / (((SIM_CLKDIV1 & SIM_CLKDIV1_OUTDIV1_MASK) >> 28)+ 1);
        
        if (TERM_PORT_NUM == 1) 
         {
           uart_init (UART1_BASE_PTR, core_clock_khz, TERMINAL_BAUD);
         }
        else
        {
           periph_clk_khz = core_clock_khz / (((SIM_CLKDIV1 & SIM_CLKDIV1_OUTDIV4_MASK) >> 16)+ 1);
          uart_init (UART2_BASE_PTR, periph_clk_khz*2, TERMINAL_BAUD);//
        }
          
     }
}

void uart_lowpower_edge(void)
{
      SIM_SOPT2 &= ~SIM_SOPT2_UART0SRC_MASK;
      SIM_SOPT2 |= SIM_SOPT2_UART0SRC(1); // select the MCG_FLL as UART0 clock source
      
      MCG_C2 &= ~MCG_C2_IRCS_MASK;
      MCG_C1 &= ~(MCG_C1_IRCLKEN_MASK | MCG_C1_IREFSTEN_MASK); // disable the IRCLK
      
      uart0_clk_khz = (mcg_clk_hz / 1000); // the uart0 clock frequency will equal the FLL frequency
     
      uart0_init (UART0_BASE_PTR, uart0_clk_khz, TERMINAL_BAUD);    
      UART0_C1 |= UART0_C1_ILT_MASK;  // Idle count start from stop bit
      UART0_C2 |= UART0_C2_RIE_MASK;  // enable receive interrupt
      UART0_BDH |= UART0_BDH_RXEDGIE_MASK;
      enable_irq (UART0SE_irq_no);
}
void uart_lowpower_data(void)
{
      SIM_SOPT2 &= ~SIM_SOPT2_UART0SRC_MASK;
      SIM_SOPT2 |= SIM_SOPT2_UART0SRC(3); // select the MCGIRCLK as UART0 clock source
      
      MCG_C2 |= MCG_C2_IRCS_MASK;
      MCG_C1 |= MCG_C1_IRCLKEN_MASK | MCG_C1_IREFSTEN_MASK; // enable the IRCLK
      MCG_SC &= ~MCG_SC_FCRDIV_MASK;
      MCG_SC |= MCG_SC_FCRDIV(0);
      
      uart0_clk_khz = (fast_irc_freq / 1000); // UART0 clock frequency will equal the OSCERCLK frequency
     
      uart0_init (UART0_BASE_PTR, uart0_clk_khz, TERMINAL_BAUD); 
     
      UART0_C1 |= UART0_C1_ILT_MASK;  // Idle count start from stop bit
      UART0_C2 |= UART0_C2_RIE_MASK;  // enable receive interrupt
      enable_irq (UART0SE_irq_no);
}

/*******************************************************************************************************/
void clockMonitor(unsigned char state)
{
    if(state)
      MCG_C6 |= MCG_C6_CME0_MASK;
    else
      MCG_C6 &= ~MCG_C6_CME0_MASK;
}
  


void systick_isr(void)
{
  //disable systick
  SYST_CSR &= ~(SysTick_CSR_ENABLE_MASK  | 
                SysTick_CSR_TICKINT_MASK |
                SysTick_CSR_CLKSOURCE_MASK); 
  SYST_RVR = 0x00000000;
  
}

void enable_systick(void)
{
  SYST_RVR = 0x00002000; //SysTick Reload Value Register
  SYST_CVR = 0x00000000;
  SYST_CSR = SysTick_CSR_ENABLE_MASK | 
             SysTick_CSR_TICKINT_MASK |
             SysTick_CSR_CLKSOURCE_MASK;
}
